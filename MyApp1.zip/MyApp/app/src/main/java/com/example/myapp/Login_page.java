package com.example.myapp;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class Login_page extends AppCompatActivity {
private Button log_in, log_reg;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_page);


        log_reg = (Button) findViewById(R.id.logRegId) ;


        log_in = (Button) findViewById(R.id.sign_in_login_Id);



        log_reg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Login_page.this,Registration.class);
                startActivity(intent);
            }
        });



        log_in.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Login_page.this,FirstPage.class);
                Toast.makeText(Login_page.this, "Welcome to our Apps ", Toast.LENGTH_SHORT).show();
                startActivity(intent);
            }
        });


    }
}