package com.example.myapp;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Email extends AppCompatActivity {
private EditText To , Sub , Messages;
private Button send;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_email);


        To = (EditText) findViewById(R.id.emailTo_text);
        Sub = (EditText) findViewById(R.id.emailSub_text);
        Messages=(EditText) findViewById(R.id.emailMessage_text);
        send= (Button) findViewById(R.id.emailSend);


        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Intent.ACTION_VIEW,
                        Uri.parse("mailTo" +To.getText().toString()));
                intent.putExtra(Intent.EXTRA_SUBJECT, Sub.getText().toString());
                intent.putExtra(Intent.EXTRA_SUBJECT,Messages.getText().toString());
                startActivity(intent);
            }
        });


    }
}