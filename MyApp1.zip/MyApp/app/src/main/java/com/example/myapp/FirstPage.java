package com.example.myapp;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

public class  FirstPage extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
private Button profile , home;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_first_page);

        profile = (Button) findViewById(R.id.profileId);
        home = (Button) findViewById(R.id.homeId);

        profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(FirstPage.this,Profile.class);
                Toast.makeText(FirstPage.this, "welcome to your profile", Toast.LENGTH_SHORT).show();
                startActivity(intent);
            }
        });
        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(FirstPage.this,MainActivity.class);
                startActivity(intent);
            }
        });


        Spinner spinner = findViewById(R.id.spinner_Id);

        //ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,R.layout.activity_first_page,R.id.spinner_Id,districtName);






       ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,R.array.districtName,android.R.layout.simple_spinner_item);
       adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(this);
    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
        String text = adapterView.getItemAtPosition(i).toString();
        Toast.makeText(adapterView.getContext(),i,Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }
}